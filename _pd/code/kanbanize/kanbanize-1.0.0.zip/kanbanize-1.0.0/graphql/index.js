module.exports = {
  query: require('./query'),
  mutation: require('./mutation')
}
