#!/bin/bash
now && now alias
